import java.util.Scanner;

public class casestudy2trongcay {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		float chieuDaiSan;
		float banKinhCay, khoangCachCay, soLuongCay;
		double dienTichCay;

		System.out.print("Nhập vào chiều dài sân: ");
		chieuDaiSan = Float.parseFloat(scan.nextLine());
		System.out.println("Nhập vào bán kính cây trưởng thành: ");
		banKinhCay = Float.parseFloat(scan.nextLine());
		System.out.println("Nhập vào khoảng cách cần thiết giữa các cây trưởng thành: ");
		khoangCachCay = Float.parseFloat(scan.nextLine());

		soLuongCay = Math.round(chieuDaiSan / (banKinhCay * 2 + khoangCachCay));
		dienTichCay = (Math.sqrt(banKinhCay) * 3.14f) * soLuongCay;

		System.out.println("Số lượng cây có thể trồng là: " + soLuongCay);
		System.out.println("Tổng diện tích các cây trồng sau khi trưởng thành là: " + dienTichCay);

	}

}
