package bai6;

import java.util.Scanner;

public class Bai6 {

	public static void main(String[] args) {
		//Tinh giá trị P(x) = ax ^ n
		Scanner scanner = new Scanner(System.in);
		System.out.println("Nhập x: ");
		int x = Integer.parseInt(scanner.nextLine());
		System.out.println("Nhập số thực a: ");
		float a = Float.parseFloat(scanner.nextLine());
		System.out.println("Nhập n với n > 0: ");
		int n = Integer.parseInt(scanner.nextLine());

		double ketQua = Math.pow((a * x), n);
		System.out.println("P(x) = ax ^ n có kết quả P = " + ketQua);

	}

}
