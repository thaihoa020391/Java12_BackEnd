package bai3;

import java.util.Scanner;

public class Bai3 {

	public static void main(String[] args) {
		final int TI_GIA = 23500;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Nhập số tiền USD muốn quy đổi: ");
		int tienUSD = Integer.parseInt(scanner.nextLine());
		int tienVND = tienUSD * TI_GIA 
		System.out.println("Số tiền trên có giá trị tương đương " + tienVND + " VND");
	}

}
