package bai5;
import java.util.Scanner;

public class Bai5 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Hãy nhập vào 1 số nguyên có 2 chữ số: ");
		int soBanDau = Integer.parseInt(scanner.nextLine());
		int hangChuc = soBanDau / 10;
		int hangDonVi = soBanDau % 10;
		int tong = hangChuc + hangDonVi;
		System.out.println("Tổng 2 ký số vừa nhập là " + tong);

	}

}
