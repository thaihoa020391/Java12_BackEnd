import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        final int LUONG_NGAY = 100000;
        Scanner scanner = new Scanner(System.in);
	System.out.print("Nhập số ngày công của nhân viên: ");
	int soNgayCong = Integer.parseInt(scanner.nextLine());
        int tienLuong = soNgayCong * LUONG_NGAY;
        System.out.println("Tiền lương của nhân viên là: " + tienLuong);
    }
}
